// jest custom assertions
import '@testing-library/jest-dom'

// include style rules in snapshots
import 'jest-styled-components'
